//
// Created by Dani on 2019. 05. 09..
//

#include "Player.h"

Player::Player(int health, int damage, int armor) : Character(health, damage, armor){
}